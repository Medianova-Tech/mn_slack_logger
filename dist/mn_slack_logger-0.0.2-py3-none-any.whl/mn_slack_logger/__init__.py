__version__ = "0.0.2"

from .slack_log import SlackLogger
