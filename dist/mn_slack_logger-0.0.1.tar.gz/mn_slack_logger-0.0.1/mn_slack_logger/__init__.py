__version__ = "0.0.1"

from .slack_log import SlackLogger
